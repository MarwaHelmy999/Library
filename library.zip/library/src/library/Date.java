package library;

public class Date {

	public int day;

		public int month;
		public int year;
		
		
		Date(int day,int month,int year){
			
			this.day=day;
			this.month=month;
			this.year=year;
			
		}
		
		
		
		
		
	}


