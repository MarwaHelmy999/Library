package library;

public class Member {


	int Id;
	Book[] list_borrowed_books;
	String password ;
	
	Member(int Id,String password){
		
		this.Id=Id;
		this.password=password;
		list_borrowed_books=new Book[0];

		
	}
	void borrow(Book borrowed_book){
		Book [] list_borrowed=new Book[list_borrowed_books.length+1];
		for (int i=0;i<list_borrowed_books.length;i++){
			
			list_borrowed[i]=list_borrowed_books[i];
			
		}
		list_borrowed[list_borrowed.length-1]=borrowed_book;
		
		list_borrowed_books= list_borrowed;
	}
	
	void return_borrowed_book (Book return_book){
	boolean Last_Copy_Of_Book = false;
	boolean found = false;
	
		for(int i=0;i<list_borrowed_books.length;i++)  //list_borrowed_books the original matrix
		{
			if (list_borrowed_books[i].title.equals(return_book.title) &&list_borrowed_books[i].author.equals(return_book.author)){
				found=true;
				if(list_borrowed_books[i].numofcopies==1)
				{Last_Copy_Of_Book=true;}
				else
				{list_borrowed_books[i].numofcopies++;}
			}
		}		
		if(!found)
		{
			System.out.println("Book isn't in Borrowed list.");
		}
		if(Last_Copy_Of_Book){
		Book[]list_borrowed=new Book[list_borrowed_books.length-1];
		int delete_index =0;
		
		for(int i=0;i<list_borrowed_books.length;i++)  //list_borrowed_books the original matrix
		{
			if (list_borrowed_books[i].title.equals(return_book.title) &&list_borrowed_books[i].author.equals(return_book.author)){
				delete_index =i;
				found = true;
			}
		}
		if(found == true)
		{
			int copyat=0;  // copyat is a variable move with i to check the place of the index we want to delete when we find
                           //the required element i will increase by 1 but copy at will not then we take the element at copyat++   
			               //and put it in the original matrix by that we skiped the element at copyat (same as we deleted it from original array)
			for (int i=0;i<list_borrowed_books.length;i++){
				
				if(i==delete_index)
					continue;
				list_borrowed[copyat++]=list_borrowed_books[i];
			}
		list_borrowed_books = list_borrowed;
					
		}
		else{System.out.println("Book isn't in Borrowed list.");}
		}
		
	}
	
	void Show_borrowed_book(){
		for(int i =0;i<list_borrowed_books.length;i++)
		{
			
			System.out.println("Book "+(i+1));
			System.out.println("Book's title:"+list_borrowed_books[i].title);
			System.out.println("Book's author:"+list_borrowed_books[i].author);
			
		}
	}
	
	
}
