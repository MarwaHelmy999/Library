package library;

public class Library {
	Book[]books;
    Library() {
				books = new Book[0];
			}
	void Insert(Book book)
	{ boolean old =false;
		for(int i =0;i<books.length;i++){

		if(books[i].title.equals(book.title)&&books[i].author.equals(book.author)){
			books[i].numofcopies++;
			old =true;
		}}
		if(old==false){
		//initializing a bigger array
		Book[] new_Books = new Book[books.length+1];
		//copy old items from small array
		for(int i =0;i<books.length;i++)
		{
			new_Books[i]= books[i];
		}
		//insert the new element at the end of big array
		new_Books[books.length]= book;          //length-1 to put the new book in the last place in the array
		
		//making old array points to the big array
		books = new_Books;
		new_Books=books;
		}
	}
	
Book Search_By_Title(String title){
	int FirstBook =-1;
	for(int i =0;i<books.length;i++)
	{
		if(books[i].title.equalsIgnoreCase(title))
		{
		System.out.println("Book's title: "+books[i].title);
		System.out.println("Book's author: "+books[i].author);
		System.out.println("Book's Copies Number is: "+books[i].numofcopies);
		if(FirstBook==-1)
		{
			FirstBook=i;
		}
		}
	}
	if(FirstBook!=-1)
	{
		return books[FirstBook];
	}
	else
	{System.out.println(" not found ");
	return null;}
}

Book Search_By_author(String author_name){
	int FirstBook =-1;
	for(int i =0;i<books.length;i++)
	{
		if(books[i].author.equals(author_name))
		{
			System.out.println("Book's title:"+books[i].title);
			System.out.println("Book's author:"+books[i].author);
			System.out.println("Book's Copies Number is:"+books[i].numofcopies);
			if(FirstBook==-1)
			{
				FirstBook=i;
			}
			
		}
	}
	if(FirstBook!=-1)
	{
		return books[FirstBook];
	}
	
	System.out.print("Book not found");
	return null;
}
void Show_Books(){
	
	for(int i =0;i<books.length;i++)
	{

		
			System.out.println("Book's title:"+books[i].title);
			System.out.println("Book's author:"+books[i].author);
			System.out.println("Book's Copies Number is:"+books[i].numofcopies);
	}
	
}
void delete (String title){
Book[]new_books=new Book[books.length-1];
	
	for(int i=0;i<books.length;i++)
	{
		if (books[i].title.equals(title)){
			if(books[i].numofcopies>0) {
			books[i].numofcopies--;
                 System.out.println("the copy of the book is deleted successfully");
                 System.out.println("the current num of copies is"+books[i].numofcopies);
			}
			else{System.out.println("Book not found.");}

		}	
	}

	}
	

Book  borrow(String title){
	
	for(int i =0;i<books.length;i++)
	{
		if(books[i].title.equals(title))
		{
			if (books[i].numofcopies==0){
			System.out.print("sorry the book is already borrowed");
			}
			else if(books[i].numofcopies>0){
				System.out.println("you have successfully borrowed");
				books[i].numofcopies--; 
				System.out.print("we have "+books[i].numofcopies+" copies");
				return books[i];
			}
		}
	}
	
	return null;
}

void return_book(Book b){
	for(int i =0;i<books.length;i++){
		if(books[i].title == b.title && books[i].author == b.author){
			books[i].numofcopies++;
			System.out.println("there is "+books[i].numofcopies+"copy of this book");
		}
	}
}

public  boolean valid(String title ){
	for(int i =0;i<books.length;i++)
{
	if(books[i].title.equalsIgnoreCase(title))
	{
		return true;
	}
}

return false;
} 


}






















