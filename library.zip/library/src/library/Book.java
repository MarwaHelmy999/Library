package library;

	


public class Book {

	
	String title;
	int numofcopies;
	String author; 
	
	Date date_of_publishing ;
Book(String title,String author,Date date_of_publishing,int numofcopies){
	this.title= title;
	this.author = author;
	this.date_of_publishing = date_of_publishing;
	this.numofcopies=numofcopies;
	
	
	
}
	
	}


