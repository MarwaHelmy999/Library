package library;

import java.util.Scanner;

public class Final {
	public static Scanner s =new Scanner(System.in);
	public static Member [] Members;

	public static void main(String[] args) {
		Members = new Member[0];
		System.out.println("Welcom Mr admin" );
		System.out.println("" );
		System.out.println("First Enter some of Books and Members." );
		Library library = new Library();
		
		while (true){
		
	
		System.out.println("Which one of the following operation would you like to do? ,please press" );
		
		System.out.println("1- for Book insertion" );
		System.out.println("2- for borrowing a book" );
		System.out.println("3- Searching for a Book " );
		System.out.println("4- to Delete a copy" );
		System.out.println("5- to Delete a user" );
		System.out.println("6 to return a Book" );
		System.out.println("7 to add a Member" );
		System.out.println("8 to Show a Member Borrow List " );
		System.out.println("-1 to exit the program." );
		
		int k =s.nextInt();
		
	if (k==1){
		Date Book_Date = Get_Date();
		System.out.print("Enter Title : " );
		String title = s.next();
		System.out.print("Enter Author : " );
		String Author = s.next();
		System.out.print("Enter Copies Number of book : " );
		int numofcopies = s.nextInt();
		
		Book B = new Book(title, Author, Book_Date, numofcopies);
		library.Insert(B);
		System.out.println("The book has inserted successfully");
		System.out.println("we have"+numofcopies+"copy of this book");
		
	
	}
	if (k==2){
		try{
		if(Members.length==0){System.out.println("You have to the operation 7 Firstly");
		continue;
		}
		System.out.print("please enter the Id");
		int Id = s.nextInt();                           boolean found=false;
		for (int i=0;i<Members.length;i++){
			
			if(Members[i].Id==Id){
				found = true;
				System.out.println("How long you want to borrow ?     1:14 days Available ..");
				int Duration= -1;
				while(Duration<1 ||Duration >14)
				 {System.out.print("borrow duration must not exceed 14 day");
					Duration = s.nextInt();

				if(Duration<1 ||Duration >14)
				System.out.println("Invalid duration Please Enter a Valid Duration ");
				
				 }
				System.out.println("please enter the title of the book ");
				
				System.out.println("We Have : ");
				library.Show_Books();
				
				String title=s.next();
				if (library.valid(title)){
					System.out.println("Found");
					
					Book Borrow_Book = library.Search_By_Title(title);
					Members[i].borrow(Borrow_Book);
					library.borrow(title);
					System.out.println("The borrowing operation completed successfully");
					
				}
				else if (library.books.length==0){
					System.out.println("you have to insert a book firstly for that choose operation 1");
				}
				else{	System.out.println("Book not found");
				}
			}
		}
		if(!found){
			System.out.println("Borrow is  available for members only.");
		}
		}catch(Throwable e){System.err.println(e.getMessage());
		e.printStackTrace(System.err);}
	}
	if(k== 7)
	{
		System.out.print("Enter a ID");
		int id = s.nextInt();
		System.out.print("Enter Password");
		String password = s.next();
		Member Mem = new Member(id, password);
		Insert_Member(Mem);
		System.out.println("You have added a Member successfully ");
	}
	if(k ==5)
	{
		System.out.print("Enter a USer ID to Delete it");
		int ID = s.nextInt();
		Delete_Member(ID);
		System.out.println("Delete user is done successfully");
	}
	if(k==3)
	{
		System.out.println("for Search by title Enter 1, for Search by author Enter 2");
		int choice = s.nextInt();
		
		if(choice==1)
		{		System.out.print("Enter a Title: ");
		String Title = s.next();
		library.Search_By_Title(Title);
		}
		else
			if(choice==2)
			{
				System.out.print("Enter a Author: ");
				String Author = s.next();
				library.Search_By_author(Author);

			}
	}
	if(k==6)
	{
		System.out.print("Enter the Id of the user who return the book ");
		int ID = s.nextInt();
		
		System.out.println("Enter the information of reterned book ");

		Date Book_Date = Get_Date();
		System.out.print("Enter Title : " );
		String title = s.next();
		System.out.print("Enter Author : " );
		String Author = s.next();
		System.out.print("Enter Copies Number of book : " );
		int num_of_copies = s.nextInt();
		
		Book B = new Book(title, Author, Book_Date, num_of_copies);
		boolean found = false;
		for(int i =0;i<Members.length;i++)
		{
			if(Members[i].Id== ID)
			{ found = true;
				if(library.valid(title))
				{
				Members[i].return_borrowed_book(B);
				library.return_book(B);
				System.out.println("The boook is returned successfully");
				}
				else
				{
			System.out.print("Book isn't from Library");
				}
			}
		}
		if(!found)
		{
			System.out.print("Can't find user specified ");
		}
		

	}
	
	if(k==4)
	{
		System.out.print("Enter the title of the Book to delete");
		String title = s.next();
		
		library.delete(title);
		
	}
	if(k==8){
		boolean found = false;
		System.out.println("Enter the Id of the Member");
		int id = s.nextInt();
		
		for(int i=0;i<Members.length;i++)
		{
			if(Members[i].Id==id)
			{found =true;
			System.out.println("the list of borrowed books is");
				Members[i].Show_borrowed_book();
			}
			
		}
		if(!found)
		{System.out.println("Can't Find a Member For this ID.");}
		
	}
	if(k==-1){
		System.out.println("the program is closed ");
		System.out.println("============================= ");

		return ;
	}
		}
		
	}

	
	
	//Helper Functions
	//
	public static Date Get_Date()
	{
		System.out.println("-Date of bublishing" );
		System.out.print("Enter Day : " );
		int day = s.nextInt();
		System.out.print("Enter month : " );
		int month = s.nextInt();
		System.out.print("Enter Year : " );
		int year = s.nextInt();
		Date  Date_of_Publishing = new Date(day, month, year) ;
		return Date_of_Publishing;
	}
	public static void Insert_Member(Member M)
	{
	Member[] New_Mem = new  Member[Members.length+1]; 	
	for(int i =0;i<Members.length;i++){
		New_Mem[i]=	Members[i];
	}
	New_Mem[New_Mem.length-1]=M;
	Members = New_Mem;
			
	
	}
	public static void Delete_Member(int id)
	{
		Member[]new_Members=new Member[Members.length-1];
		int delete_index =0;
		boolean found = false;
		
		for(int i=0;i<Members.length;i++)
		{
			if (Members[i].Id==id){
				delete_index =i;
				found = true;
			}
		}
		if(found == true)
		{
			int copyat=0;
			for (int i=0;i<Members.length;i++){
				
				if(i==delete_index)
					continue;
				new_Members[copyat++]=Members[i];
			}
			Members = new_Members;		
		}
		else{System.out.println("Member is not found.");}


	}
}
